<footer>
        <ul>
            <li>Copyright &copy; 2022 Beetabie.All Right Reserved</li>
            <li>Developed by <a href="#">Subhankar sarkar</a></li>
        </ul>
    </footer>