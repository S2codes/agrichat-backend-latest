<?php
// fetch all districts  
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

include "../auth.php";

// fetch group details 
function fetch_group_details($groupId, $DB)
{
    $qry = "SELECT * FROM `chatgroups` WHERE id = $groupId";
    return $DB->RetriveSingle($qry);
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {

    // api authentication 
    if (!isset($_GET['api_key'])) {
        echo json_encode(
            array(
                'message' => 'Invalid api key',
                'response' => false,
                'status' => '401'
            )
        );
        exit();
    }

    if ($api_auth != $_GET['api_key']) {
        echo json_encode(
            array(
                'message' => 'Invalid api key',
                'response' => false,
                'status' => '401'
            )
        );
        exit();
    } else {

        // get parameters 
        $userid = $_GET['user_id'];

        if (!isset($userid) || $userid == '') {
            echo json_encode(
                array(
                    'message' => 'Invalid User',
                    'response' => false,
                    'status' => '400'
                )
            );
        }

        $s = "SELECT * FROM `joinedgroups` WHERE userid = '$userid' AND `selected` = 1";
        $userjoinedGroups = $DB->RetriveArray($s);

        $pinnedGroup = array();
        $selectedGroup = array();

        $pinnedGroupId = array();
        $selectedGroupId = array();

        foreach ($userjoinedGroups as $key => $group) {
            array_push($selectedGroupId, $group['groupid']);
            
            if ($group['pin'] != "0" || $group['pin'] == "1") {
                $g = fetch_group_details($group['groupid'], $DB);
                array_push($pinnedGroup, $g);
                array_push($pinnedGroupId, $group['groupid']);
            }else{
                $g = fetch_group_details($group['groupid'], $DB);
                array_push($selectedGroup, $g);
            }
        }


        echo json_encode(
            array(
                'message' => 'Success',
                'response' => true,
                'status' => '200',
                "selectedGroups" => $selectedGroup,
                "selectedGroupsId" => $selectedGroupId,
                "pinnedGroups" => $pinnedGroup,
                "pinnedGroupsId" => $pinnedGroupId
            )
        );
    }
}
